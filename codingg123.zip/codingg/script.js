/* ======================================
   ATTENDX AI
   SCRIPT.JS
====================================== */

// Smooth Scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
        const targetAttr = this.getAttribute("href");
        if (targetAttr && targetAttr.startsWith("#") && targetAttr.length > 1) {
            e.preventDefault();
            const target = document.querySelector(targetAttr);
            if (target) {
                target.scrollIntoView({
                    behavior: "smooth"
                });
            }
        }
    });
});

// Sticky Navbar Effect
const header = document.querySelector("header");
if (header) {
    window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
            header.style.background = "rgba(8,20,32,.55)";
            header.style.backdropFilter = "blur(25px)";
            header.style.transition = ".3s";
        } else {
            header.style.background = "transparent";
        }
    });
}

// Active Navigation
const sections = document.querySelectorAll("section");
const navLinks = document.querySelectorAll("nav ul li a");
window.addEventListener("scroll", () => {
    let current = "";
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 120;
        if (window.scrollY >= sectionTop) {
            current = section.getAttribute("id");
        }
    });

    navLinks.forEach(link => {
        link.classList.remove("active");
        if (link.getAttribute("href") == "#" + current) {
            link.classList.add("active");
        }
    });
});

// Fade Up Animation
const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("show");
        }
    });
});

document.querySelectorAll(".feature-card,.about,.contact,.stats,.dashboard,.phone").forEach(el => {
    el.classList.add("fade-up");
    observer.observe(el);
});

// Counter Animation
const counters = document.querySelectorAll(".stats h2");
let counted = false;

window.addEventListener("scroll", () => {
    const stats = document.querySelector(".stats");
    if (!stats) return;

    if (window.scrollY > stats.offsetTop - 500 && !counted) {
        counted = true;
        counters.forEach(counter => {
            let target = counter.innerText;
            let number = parseInt(target);
            let suffix = target.replace(number, "");
            let current = 0;
            let speed = Math.ceil(number / 60);

            let interval = setInterval(() => {
                current += speed;
                if (current >= number) {
                    current = number;
                    clearInterval(interval);
                }
                counter.innerText = current + suffix;
            }, 25);
        });
    }
});

// Blob Mouse Parallax
const blobs = document.querySelectorAll(".blob");
document.addEventListener("mousemove", (e) => {
    let x = e.clientX / window.innerWidth;
    let y = e.clientY / window.innerHeight;

    blobs.forEach((blob, index) => {
        let speed = (index + 1) * 18;
        blob.style.transform = `translate(${x * speed}px,${y * speed}px)`;
    });
});

// Button Ripple Effect
document.querySelectorAll(".primary-btn,.secondary-btn,.start-btn").forEach(btn => {
    btn.addEventListener("mouseenter", () => {
        btn.style.transform = "translateY(-5px) scale(1.03)";
    });
    btn.addEventListener("mouseleave", () => {
        btn.style.transform = "translateY(0px) scale(1)";
    });
});

// Dashboard Graph Animation
const bars = document.querySelectorAll(".graph div");
if (bars.length > 0) {
    setInterval(() => {
        bars.forEach(bar => {
            let height = Math.floor(Math.random() * 90) + 40;
            bar.style.height = height + "px";
        });
    }, 1800);
}

console.log("%cAttendX AI Loaded Successfully 🚀", "color:#82E9DE;font-size:18px;font-weight:bold;");
