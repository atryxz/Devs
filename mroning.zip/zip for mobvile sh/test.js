/* ======================================
   ATTENDX AI
   HOMEPAGE & SUBPAGES JS
====================================== */

// ===============================
// Smooth Scroll
// ===============================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
        const href = this.getAttribute("href");
        if (href === "#") return;
        
        const target = document.querySelector(href);
        if (target) {
            e.preventDefault();
            target.scrollIntoView({
                behavior: "smooth"
            });
        }
    });
});

// ===============================
// Sticky Navbar Effect
// ===============================

const header = document.querySelector("header");

if (header) {
    window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
            header.style.background = "rgba(8, 20, 32, 0.75)";
            header.style.backdropFilter = "blur(25px)";
            header.style.webkitBackdropFilter = "blur(25px)";
            header.style.boxShadow = "0 10px 30px rgba(0,0,0,0.2)";
        } else {
            header.style.background = "transparent";
            header.style.boxShadow = "none";
        }
    });
}

// ===============================
// Active Navigation Handling
// ===============================

const sections = document.querySelectorAll("section[id]");
const navLinks = document.querySelectorAll("nav ul li a");

if (sections.length > 0) {
    window.addEventListener("scroll", () => {
        let current = "";
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 150;
            if (window.scrollY >= sectionTop) {
                current = section.getAttribute("id");
            }
        });

        if (current) {
            navLinks.forEach(link => {
                const href = link.getAttribute("href");
                if (href === "#" + current || href.endsWith("#" + current)) {
                    navLinks.forEach(l => l.classList.remove("active"));
                    link.classList.add("active");
                }
            });
        }
    });
}

// ===============================
// Fade Up Intersection Observer
// ===============================

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("show");
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll(
    ".feature-card, .about, .contact, .stats, .dashboard, .phone, " +
    ".feature-detail-card, .step-card, .story-box, .value-card, .team-card, .comparison-table-wrapper"
).forEach(el => {
    el.classList.add("fade-up");
    observer.observe(el);
});

// ===============================
// Counter Animation
// ===============================

const counters = document.querySelectorAll(".stats h2");
let counted = false;

if (counters.length > 0) {
    const triggerCounter = () => {
        const stats = document.querySelector(".stats");
        if (!stats) return;

        if (window.scrollY > stats.offsetTop - window.innerHeight + 100 && !counted) {
            counted = true;
            counters.forEach(counter => {
                let target = counter.innerText.trim();
                let number = parseInt(target);
                if (isNaN(number)) return;

                let suffix = target.replace(number.toString(), "");
                let current = 0;
                let speed = Math.ceil(number / 50);

                let interval = setInterval(() => {
                    current += speed;
                    if (current >= number) {
                        current = number;
                        clearInterval(interval);
                    }
                    counter.innerText = current + suffix;
                }, 30);
            });
        }
    };

    window.addEventListener("scroll", triggerCounter);
    // Trigger once on load in case stats section is in view
    triggerCounter();
}

// ===============================
// Blob Mouse Parallax
// ===============================

const blobs = document.querySelectorAll(".blob");

if (blobs.length > 0) {
    document.addEventListener("mousemove", (e) => {
        let x = e.clientX / window.innerWidth;
        let y = e.clientY / window.innerHeight;

        blobs.forEach((blob, index) => {
            let speed = (index + 1) * 18;
            blob.style.transform = `translate(${x * speed}px, ${y * speed}px)`;
        });
    });
}

// ===============================
// Button Micro Interactions
// ===============================

document.querySelectorAll(".primary-btn, .secondary-btn, .start-btn").forEach(btn => {
    btn.addEventListener("mouseenter", () => {
        btn.style.transform = "translateY(-4px) scale(1.02)";
    });

    btn.addEventListener("mouseleave", () => {
        btn.style.transform = "translateY(0px) scale(1)";
    });
});

// ===============================
// Dashboard Graph Animation
// ===============================

const bars = document.querySelectorAll(".graph div");

if (bars.length > 0) {
    setInterval(() => {
        bars.forEach(bar => {
            let height = Math.floor(Math.random() * 90) + 40;
            bar.style.height = height + "px";
        });
    }, 1800);
}

// ===============================
// Phone Floating Glow
// ===============================

const phone = document.querySelector(".phone");

if (phone) {
    let glow = true;
    setInterval(() => {
        if (glow) {
            phone.style.boxShadow = "0 0 45px rgba(130, 233, 222, 0.45)";
        } else {
            phone.style.boxShadow = "0 20px 40px rgba(0, 0, 0, 0.35)";
        }
        glow = !glow;
    }, 1200);
}

// ===============================
// Console Status
// ===============================

console.log("%cAttendX AI Loaded Successfully 🚀", "color:#82E9DE; font-size:16px; font-weight:bold;");